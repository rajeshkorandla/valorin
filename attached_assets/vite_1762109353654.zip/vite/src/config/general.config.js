const generalSettings = {
  purchaseLink: 'https://1.envato.market/Vm7VRE',
  docsLink: '',
  licenseLink: '',
  devsLink: 'https://devs.keenthemes.com',
  faqLink: 'https://keenthemes.com/metronic',
  aboutLink: 'https://keenthemes.com/metronic',
};

export { generalSettings };
