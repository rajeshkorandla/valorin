export * from './product-details-content';
export * from './product-details-page';
