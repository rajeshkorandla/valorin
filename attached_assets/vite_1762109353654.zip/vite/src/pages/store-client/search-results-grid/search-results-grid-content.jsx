import { SearchResults } from './components';

export function SearchResultsGridContent() {
  return <SearchResults mode="card" />;
}
