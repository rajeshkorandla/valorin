import { MyOrders } from './components/my-orders';

export function MyOrdersContent() {
  return <MyOrders />;
}
