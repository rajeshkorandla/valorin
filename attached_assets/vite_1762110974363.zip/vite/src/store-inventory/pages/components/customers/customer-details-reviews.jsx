'use client';

import { CardDate } from './components/card-date';

export function CustomerDetailsReviews() {
  return <CardDate />;
}
