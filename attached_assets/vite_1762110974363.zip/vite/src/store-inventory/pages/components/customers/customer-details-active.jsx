'use client';

import { ActivityPage } from './components/activity/page';

export function CustomerDetailsActivity() {
  return <ActivityPage />;
}
