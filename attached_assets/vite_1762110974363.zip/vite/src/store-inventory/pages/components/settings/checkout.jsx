'use client';

export function Checkout() {
  return <div className="space-y-5"></div>;
}
