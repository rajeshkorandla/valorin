export const ESTIMATED_ARRS = [
  {
    id: '1',
    name: '0-100K',
    color: 'bg-red-50 text-red-700 dark:bg-red-950/50 dark:text-red-200',
  },
  {
    id: '2',
    name: '100K-500K',
    color: 'bg-teal-50 text-teal-700 dark:bg-teal-950/50 dark:text-teal-200',
  },
  {
    id: '3',
    name: '500K-1M',
    color: 'bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-200',
  },
  {
    id: '4',
    name: '1M-5M',
    color:
      'bg-yellow-50 text-yellow-700 dark:bg-yellow-950/50 dark:text-yellow-200',
  },
  {
    id: '5',
    name: '5M-50M',
    color:
      'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-200',
  },
  {
    id: '6',
    name: '50M+',
    color:
      'bg-violet-50 text-violet-700 dark:bg-violet-950/50 dark:text-violet-200',
  },
];
